#include<iostream>
using namespace std;
int main()
{
	double a, b, c;
	cin >> a >> b >> c;
	if ((a + b) > c)
		cout << "it's sides of a Triangle";
	else
		cout << "it's not sides of a Triangle";
		return 0;
}